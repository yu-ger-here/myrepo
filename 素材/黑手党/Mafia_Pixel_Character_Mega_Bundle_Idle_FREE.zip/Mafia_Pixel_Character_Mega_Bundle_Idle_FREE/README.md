# Mafia Pixel Character Mega Bundle — FREE Idle Sample

This free sample contains source-exact neutral standing poses from the full pack.

## Included
For each of the 4 variants (**Blue, Bold, Creepy, Red**):
- 4 individual 32×32 transparent PNG idle-direction poses: Front/Down, Left, Right, Back/Up
- 1 horizontal 128×32 directional idle sheet
- 1 one-frame Front Idle GIF
- 1 directional showcase GIF for presentation

## Accuracy note
The original source does not include a dedicated multi-frame breathing/idle animation. To avoid inventing movement, these files use the exact neutral stance frame from the source sheet. The directional showcase GIF changes facing direction only and is not intended as an in-game idle animation.

The PNGs are not watermarked, recolored, blurred, or degraded.

Credit appreciated, not required: **Assets: eufil — JoyCat**
Fiverr: https://www.fiverr.com/eufilx
